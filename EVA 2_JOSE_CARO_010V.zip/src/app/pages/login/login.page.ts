import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/servicios/auth.service';
import { AlertController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';
import { Router } from '@angular/router';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { MenuController } from '@ionic/angular';
import { AlumnoPage } from '../alumno/alumno.page';
@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  MostrarMenu() {
    this.menuController.enable(true, 'tuMenuId'); // Reemplaza 'tuMenuId' con el ID de tu menú
  this.menuController.open('tuMenuId'); // Reemplaza 'tuMenuId' con el ID de tu menú
  }

  loginForm: FormGroup;

  userdata:any;

  usuario={
    id:0,
    username:"",
    password:"",
    role:"",
    isactive: false
  }

  constructor(private authservice: AuthService,
              private router: Router,
              private alertcontroller: AlertController,
              private toastcontroller: ToastController,
              private menuController: MenuController,
              private fbuilder: FormBuilder) { 
                this.loginForm = this.fbuilder.group({
                  'username' : new FormControl("", [Validators.required, Validators.minLength(4)]),
                  'password': new FormControl("", [Validators.required, Validators.minLength(4)])
                  
                })
                
              }
              Alumno() {
                this.router.navigate(['/alumno']); // Reemplaza 'alumno' con la ruta correcta para tu página de Alumno
              }

  ngOnInit() {
  }

  login(){
    if (this.loginForm.valid){
      this.authservice.getUserByName(this.loginForm.value.username).subscribe(resp=>{
        this.userdata=resp;
        console.log(this.userdata);
        if (this.userdata.length>0){    //si encontramos el objeto el length devuelve valor 1
          this.usuario={
            id : this.userdata[0].id,
            username: this.userdata[0].username,
            password: this.userdata[0].password,
            role: this.userdata[0].role,
            isactive: this.userdata[0].isactive
          }
          if (this.usuario.password === this.loginForm.value.password){
            //iniciamos session
            sessionStorage.setItem('username',this.usuario.username);
            sessionStorage.setItem('role', this.usuario.role);
            sessionStorage.setItem('ingresado', 'true');
            this.showToast('Sesion Iniciada');
            this.router.navigateByUrl("/listar");
          }

        }
      })
    }
  }//login


  async showToast(msg:any){
    const toast= await this.toastcontroller.create({
      message: msg,
      duration: 3000
    })
    toast.present();
  }


}
