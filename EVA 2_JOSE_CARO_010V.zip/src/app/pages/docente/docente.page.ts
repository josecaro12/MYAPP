import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { MenuController } from '@ionic/angular';


@Component({
  selector: 'app-docente',
  templateUrl: './docente.page.html',
  styleUrls: ['./docente.page.scss'],
})
export class DocentePage implements OnInit {

  handlerMessage='';
  roleMessage='';

  constructor(private alertController: AlertController, 
    private menuController: MenuController) { }

  ngOnInit() {
  }
  MostrarMenu(){
    this.menuController.open('first');
  }

//método que permite ingresar datos en un alert
async Ingresar() {
  const alert = await this.alertController.create({
    header: 'Ingrese sus datos!',
    buttons: ['OK'],
    inputs: [
      {
        name:'nom',
        placeholder: 'Nombre..',
      },
      {
        placeholder: 'rut..',
        attributes: {
          maxlength: 8,
        },
      },
      {
        name:'edad',
        type: 'number',
        placeholder: 'dia',
        min: 1,
        max: 100,
      },
      {
        type: 'textarea',
        placeholder: 'nombre de la seccion',
      },
    ],
  });

  await alert.present();
}


 //método que crea una ventana con dos botones

 async Confirmar() {
  const alert = await this.alertController.create({
    header: 'Confirme datos!',
    buttons: [
      {
        text: 'Cancelar',
        role: 'cancel',
        handler: () => {
          this.handlerMessage = 'Alerta cancelada';
        },
      },
      {
        text: 'OK',
        role: 'confirm',
        handler: () => {
          this.handlerMessage = 'Alert confirmada';
        },
      },
    ],
  });

  await alert.present();

  const { role } = await alert.onDidDismiss();
  this.roleMessage = `Dismissed with role: ${role}`;
}


 //método que envía un QR
 async Saludar() {
  const alert = await this.alertController.create({
    header: 'Aviso',
    subHeader: 'Su codigo QR fue creado!',
    message: 'Que tengas un gran dia!',
    buttons: ['OK'],
  });

  await alert.present();
}

}
