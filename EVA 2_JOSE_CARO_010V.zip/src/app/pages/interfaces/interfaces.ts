//get,put, delete
export interface IAnimalitos{
    id:Number;
    nombre:String;
    tipoMascota: String;
    raza: String;

}

//post
export interface IAnimalito{
    nombre:String;
    tipoMascota: String;
    raza: String;
}

//get
export interface Users{
    id:number;
    username: String;
    password: String;
    role: String;
    isactive: boolean;
}