import { Component } from '@angular/core';

interface Componente{
  icon: string;
  name: string;
  redirecTo: string;
}


@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  constructor() {}

  componentes : Componente[] = [
    {
      name: 'Inicio',
      redirecTo: '/inicio',
      icon: 'home-outline'
    },
    {
      name: 'Informacion y Eventos',
      redirecTo: '/informacion',
      icon: 'information-circle-outline'
    },
    {
      name: 'Formulario de Registro',
      redirecTo: '/formulario',
      icon: 'newspaper-outline'
    },
    {
      name: 'Login Alumno',
      redirecTo: '/login',
      icon: 'person-outline'
    },
    {
      name: 'Login Docente',
      redirecTo: '/login copy',
      icon: 'person-outline'
    },
  ]




}
